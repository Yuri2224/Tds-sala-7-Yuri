using Microsoft.AspNetCore.Mvc;
using cliente.Models;

namespace cliente.Controllers
{
    public class ClienteController : Controller
    {


        public IActionResult Index()
        {

            var clientes = new List<Cliente>{
                new Cliente{
                    Id = 1,
                    Nome = "João Silva",
                    Valor = 1500.75m,
                    Desc = "Cliente VIP - Preferencial",
                    Cat = "A"
                },
                new Cliente{
                    Id = 2,
                    Nome = "Maria Oliveira",
                    Valor = 850.50m,
                    Desc = "Cliente Regular - Desconto de 10%",
                    Cat = "B"
                }
            };


            return View(clientes);
        }
    }
}
